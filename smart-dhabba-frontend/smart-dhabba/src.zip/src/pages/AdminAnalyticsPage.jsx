import React, { useEffect, useState } from "react";
import {
  getTotalOrdersToday,
  getTopItems,
  getTopRatedServers,
  getAdminSummary,
} from "../services/adminService"; // Import relevant functions

const AdminAnalyticsPage = () => {
  const [totalOrders, setTotalOrders] = useState(0);
  const [topItems, setTopItems] = useState([]);
  const [topServers, setTopServers] = useState([]);
  const [adminSummary, setAdminSummary] = useState({
    users: 0,
    orders: 0,
    topItems: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(""); // Error state for API errors
  const token = localStorage.getItem("token");

  // Fetch analytics data when the page loads
  useEffect(() => {
    const loadAnalytics = async () => {
      try {
        const ordersData = await getTotalOrdersToday(token);
        setTotalOrders(ordersData.totalOrdersToday);

        const itemsData = await getTopItems(token);
        setTopItems(itemsData);

        // const serversData = await getTopRatedServers(token);
        // setTopServers(serversData);

        const summaryData = await getAdminSummary(token);
        setAdminSummary(summaryData);
      } catch (error) {
        setError("Failed to load analytics data");
        console.error("Failed to load analytics data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadAnalytics();
  }, [token]);

  if (loading) return <p>Loading analytics...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div style={{ padding: "30px" }}>
      <h2>Admin Analytics</h2>

      {/* Display Error Message */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Total Orders */}
      <div>
        <h3>Total Orders Today</h3>
        <p>{totalOrders}</p>
      </div>

      {/* Top Items */}
      <div>
        <h3>Top Items</h3>
        <ul>
          {topItems.map((item) => (
            <li key={item._id}>
              {item.name} - Sold: {item.total}
            </li>
          ))}
        </ul>
      </div>

      {/* Top Rated Servers */}
      <div>
        <h3>Top Rated Servers</h3>
        <ul>
          {topServers.map((server) => (
            <li key={server._id}>
              {server.serverInfo.username} - Rating: {server.avgRating}
            </li>
          ))}
        </ul>
      </div>

      {/* Admin Summary */}
      <div>
        <h3>Admin Summary</h3>
        <p>Users: {adminSummary.users}</p>
        <p>Orders: {adminSummary.orders}</p>
        <ul>
          {adminSummary.topItems.map((item) => (
            <li key={item._id}>
              {item.name} - Total Sold: {item.totalSold}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminAnalyticsPage;
