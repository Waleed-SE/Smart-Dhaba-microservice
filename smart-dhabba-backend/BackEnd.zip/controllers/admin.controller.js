const User = require("../models/User");
const Server = require("../models/Server");
const Order = require("../models/Order");
const MenuItem = require("../models/MenuItem");
const Rating = require("../models/Rating");

// Get all users (with optional filtering)
const getAllUsers = async (req, res) => {
  try {
    const role = req.query.role;
    const filter = role ? { role } : {};
    const users = await User.find(filter).select("-password");
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
};

// Change user role (e.g., promote student to server)
const updateUserRole = async (req, res) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    user.role = role;
    await user.save();
    res.status(200).json({ message: "User role updated", user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Soft delete (deactivate) user
const deactivateUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    await User.findByIdAndDelete(userId); // optionally use a 'status' flag instead
    res.status(200).json({ message: "User deleted" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

const createMenuItem = async (req, res) => {
  try {
    const item = new MenuItem(req.body);
    await item.save();
    res.status(201).json({ message: "Menu item created", item });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Update an existing menu item
const updateMenuItem = async (req, res) => {
  try {
    const { id } = req.params;
    const item = await MenuItem.findByIdAndUpdate(id, req.body, { new: true });
    if (!item) return res.status(404).json({ error: "Menu item not found" });

    res.status(200).json({ message: "Menu item updated", item });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Delete a menu item
const deleteMenuItem = async (req, res) => {
  try {
    const { id } = req.params;
    await MenuItem.findByIdAndDelete(id);
    res.status(200).json({ message: "Menu item deleted" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get all servers with basic info
const getAllServers = async (req, res) => {
  try {
    const servers = await Server.find().populate("userId", "username email");
    res.status(200).json(servers);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch servers" });
  }
};

// Toggle server availability
const toggleServerAvailability = async (req, res) => {
  try {
    const server = await Server.findById(req.params.serverId);
    if (!server) return res.status(404).json({ error: "Server not found" });

    server.isAvailable = !server.isAvailable;
    await server.save();
    res.status(200).json({ message: "Server availability updated", server });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Promote a user to server role
const promoteToServer = async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    user.role = "server";
    await user.save();

    // Create a Server profile if not already created
    const exists = await Server.findOne({ userId: user._id });
    if (!exists) {
      const server = new Server({ userId: user._id });
      await server.save();
    }

    res.status(200).json({ message: "User promoted to server", user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

const getTotalOrdersToday = async (req, res) => {
  try {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    const end = new Date();
    end.setHours(23, 59, 59, 999);

    const count = await Order.countDocuments({
      createdAt: { $gte: start, $lte: end },
    });
    res.status(200).json({ totalOrdersToday: count });
  } catch (err) {
    res.status(500).json({ error: "Failed to count orders" });
  }
};

// Top-ordered menu items
const getTopItems = async (req, res) => {
  try {
    const pipeline = [
      { $unwind: "$items" },
      {
        $group: { _id: "$items.menuItem", total: { $sum: "$items.quantity" } },
      },
      { $sort: { total: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: "menuitems",
          localField: "_id",
          foreignField: "_id",
          as: "itemDetails",
        },
      },
      { $unwind: "$itemDetails" },
    ];

    const result = await Order.aggregate(pipeline);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: "Failed to get top items" });
  }
};

// Top-rated servers
const getTopRatedServers = async (req, res) => {
  try {
    const pipeline = [
      {
        $group: {
          _id: "$ratedServerId",
          avgRating: { $avg: "$ratingValue" },
          total: { $sum: 1 },
        },
      },
      { $sort: { avgRating: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "serverInfo",
        },
      },
      { $unwind: "$serverInfo" },
    ];

    const result = await Rating.aggregate(pipeline);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: "Failed to get top-rated servers" });
  }
};

const getAdminSummary = async (req, res) => {
  const users = await User.countDocuments();
  const orders = await Order.countDocuments();
  const topItems = await Order.aggregate([
    { $unwind: "$items" },
    {
      $group: {
        _id: "$items.menuItem",
        totalSold: { $sum: "$items.quantity" },
      },
    },
    { $sort: { totalSold: -1 } },
    { $limit: 5 },
    {
      $lookup: {
        from: "menuitems",
        localField: "_id",
        foreignField: "_id",
        as: "itemDetails",
      },
    },
    {
      $project: {
        _id: 1,
        totalSold: 1,
        name: { $arrayElemAt: ["$itemDetails.name", 0] },
      },
    },
  ]);

  res.json({ users, orders, topItems });
};

module.exports = {
  getAllUsers,
  updateUserRole,
  deactivateUser,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
  getAllServers,
  toggleServerAvailability,
  promoteToServer,
  getTotalOrdersToday,
  getTopItems,
  getTopRatedServers,
  getAdminSummary,
};
