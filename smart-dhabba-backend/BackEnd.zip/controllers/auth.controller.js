const {
  registerUser,
  loginUser,
  googleAuth,
} = require("../services/auth.service");

// Signup
const signup = async (req, res) => {
  try {
    const user = await registerUser(req.body);
    res.status(201).json({ message: "User registered successfully", user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Login
const login = async (req, res) => {
  try {
    const { token, user } = await loginUser(req.body);
    res.status(200).json({ token, user });
  } catch (err) {
    res.status(401).json({ error: err.message });
  }
};

// Google OAuth Login/Register
const handleGoogleAuth = async (req, res) => {
  try {
    const { token, user } = await googleAuth(req.body);
    res.status(200).json({ token, user });
  } catch (err) {
    res.status(500).json({ error: "Google login failed" });
  }
};

module.exports = {
  signup,
  login,
  googleAuth: handleGoogleAuth,
};
