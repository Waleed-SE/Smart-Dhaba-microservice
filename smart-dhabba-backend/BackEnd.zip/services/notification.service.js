const sendNotification = (userId, message) => {
  // Implement notification logic here
  console.log(`Sending notification to user ${userId}: ${message}`);
};

module.exports = {
  sendNotification,
};
