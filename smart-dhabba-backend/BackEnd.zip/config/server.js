const express = require("express");
const cors = require("cors");

const app = express(); // ✅ Declare app before using it

// Middleware
app.use(cors());
app.use(express.json());

// Routes
const authRoutes = require("../routes/auth.routes");
app.use("/api/auth", authRoutes);

const menuRoutes = require("../routes/menu.routes");
app.use("/api/menu", menuRoutes);

const orderRoutes = require("../routes/order.routes");
app.use("/api/orders", orderRoutes);

const groupRoutes = require("../routes/group.routes");
app.use("/api/groups", groupRoutes);

const adminRoutes = require("../routes/admin.routes");
app.use("/api/admin", adminRoutes);

const uploadRoutes = require("../routes/upload.routes");
app.use("/api/uploads", uploadRoutes);
app.use("/uploads", express.static("uploads"));

// Test route
app.get("/", (req, res) => {
  res.send("Smart Dhabba Backend is live!");
});

module.exports = app;
