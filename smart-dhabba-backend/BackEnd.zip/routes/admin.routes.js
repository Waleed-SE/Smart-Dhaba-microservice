const express = require("express");
const router = express.Router();
const {
  getAllUsers,
  updateUserRole,
  deactivateUser,
  updateMenuItem,
  deleteMenuItem,
  createMenuItem,
  getAllServers,
  toggleServerAvailability,
  promoteToServer,
  getTotalOrdersToday,
  getTopItems,
  getTopRatedServers,
  getAdminSummary,
} = require("../controllers/admin.controller");

const { protect, requireRole } = require("../middleware/auth.middleware");

// Admin only
router.get("/users", protect, requireRole("admin"), getAllUsers);
router.put(
  "/users/:userId/role",
  protect,
  requireRole("admin"),
  updateUserRole
);
router.delete("/users/:userId", protect, requireRole("admin"), deactivateUser);
router.post("/menu", protect, requireRole("admin"), createMenuItem);
router.put("/menu/:id", protect, requireRole("admin"), updateMenuItem);
router.delete("/menu/:id", protect, requireRole("admin"), deleteMenuItem);
router.get("/servers", protect, requireRole("admin"), getAllServers);
router.put(
  "/servers/:serverId/toggle",
  protect,
  requireRole("admin"),
  toggleServerAvailability
);
router.put(
  "/users/:userId/promote-server",
  protect,
  requireRole("admin"),
  promoteToServer
);
router.get(
  "/analytics/orders-today",
  protect,
  requireRole("admin"),
  getTotalOrdersToday
);
router.get("/analytics/top-items", protect, requireRole("admin"), getTopItems);
router.get(
  "/analytics/top-servers",
  protect,
  requireRole("admin"),
  getTopRatedServers
);
router.get("/summary", protect, requireRole("admin"), getAdminSummary);

module.exports = router;
