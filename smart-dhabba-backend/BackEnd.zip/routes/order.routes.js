const express = require("express");
const router = express.Router();
const {
  placeOrder,
  getUserOrders,
  updateOrderStatus,
  getOrderInvoice,
} = require("../controllers/order.controller");
const { protect } = require("../middleware/auth.middleware");

router.post("/", protect, placeOrder);
router.get("/my-orders", protect, getUserOrders);
router.put("/:orderId/status", protect, updateOrderStatus);
router.get("/:orderId/invoice", protect, getOrderInvoice);

module.exports = router;
