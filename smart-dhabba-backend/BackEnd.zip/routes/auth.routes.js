const express = require("express");
const router = express.Router();
const { signup, login, googleAuth } = require("../controllers/auth.controller");

// @route   POST /api/auth/signup
// @desc    Register a new user
// @access  Public
router.post("/signup", signup);

// @route   POST /api/auth/login
// @desc    Login user with email/password
// @access  Public
router.post("/login", login);

// @route   POST /api/auth/google
// @desc    Google OAuth login/signup
// @access  Public
router.post("/google", googleAuth);

module.exports = router;
